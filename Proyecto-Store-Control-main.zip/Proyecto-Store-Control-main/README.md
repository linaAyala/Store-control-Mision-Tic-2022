# Proyecto-Store-Control
# 
# Store Control es un Software de inventario para tiendas de barrio:
# 
# Se Desarrolla una pagina web que con el Nit  y una clave se pueda identificar el negocio, esta se encuentra enfocada en los inventarios, para generar alertas que permitan identificar y conocer los productos con las fechas de vencimiento próximas, de manera  que se pueda conocer los productos con los que cuenta el establecimiento.
# 
# 
# EQUIPO DE TRABAJO
# 
# NOMBRE	        CARGO
# Juan Riascos	  Scrum Master
# Lina Ayala	    Product Owner
# Norida Pajaro	  Development Team
# Jhonier Castro	Development team
# Kheiner Murillo	Development team
# 
#
# CARACTERISTICAS DEL SOFTWARE:
# Entorno web móvil
# Amigable con el usuario
# Sitio web organizado, instintivo y con información precisa
